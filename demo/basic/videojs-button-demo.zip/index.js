var Player
var playerInstance

var ACCOUNT_ID = 'trial.straas.io-test'
var VIDEO_ID = 'encg7Z44'

/**
 * There are some changelogs, please follow the link below:
 * https://github.com/StraaS/StraaS-web-player-sdk/releases
 */
window['StraaSOnInit'] = function StraaSOnInit() {
  Player = window.StraaS.Player

  var pluginOrigin = 'https://192.168.1.72:8765'
  playerInstance = new Player('#player', {
    id: VIDEO_ID,
    accountId: ACCOUNT_ID,
    type: Player.Type.VIDEO,
    playerVars: {
      autoplay: Player.Autoplay.NO,
      loop: Player.Loop.NO,
      muted: Player.Muted.NO,
      playlistMenu: Player.PlaylistMenu.YES,
    },
    videoJsOptions: {
      controls: false
    },
    deps: [
      `${pluginOrigin}/demo/basic/videojs-button/videojs-button.js`,
      `${pluginOrigin}/demo/basic/videojs-button/index.css`
    ],
    plugins: [
      {
        name: 'customButton',
        options: {}
      }
    ]
  })
}
